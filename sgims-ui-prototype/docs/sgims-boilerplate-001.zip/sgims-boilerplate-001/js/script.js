/* Author:Donnie Wilcox

*/




function CreateStickyHeaders(){

	var clonedHeaderRow;

	$(".persist-header th").each(function () {
		$(this).css("width" , "auto"); //reset the width back to fluid each time the window resizes 
		
		});
		$(".persist-header th").each(function () {
		
		getWidth = $(this).width(); //get the "new" size 
		$(this).css("width" , getWidth); //set the size on each of the table headers
		});
		
	$(".persist-area").each(function () {
		
		$(".floatingHeader").remove();
		
		$(".persist-area thead").append('<tr class="floatingHeader" style="width:100%" />');

        clonedHeader = $(".persist-header th", this);
		
//			clonedHeader.each(function(){
//			clonedHeader.css("width", clonedHeader.width());
//			});
		
        $(".persist-area .floatingHeader").append(clonedHeader.clone());

    });

    $(window).scroll(UpdateTableHeaders).trigger("scroll");}
function UpdateTableHeaders() {
    $(".persist-area").each(function () {

        var el = $(this),
            offset = el.offset(),
            scrollTop = $(window).scrollTop(),
            floatingHeader = $(".floatingHeader", this)

            if ((scrollTop > offset.top -56) && (scrollTop < offset.top + el.height())) {
                floatingHeader.css({
                    "visibility": "visible"
                });
            } else {
                floatingHeader.css({
                    "visibility": "hidden"
                });
            };
    });
}
;
(function () {
    $('#screens-nav a').popover();
	$('.tool-tip').tooltip({trigger: 'focus'});
	// Datepicker
	if ($('.date').length > 0){$('.date').datepicker({
					changeMonth: true,
					changeYear: true
				});}
				
	
	
	CreateStickyHeaders();
	$(window).resize(function(){CreateStickyHeaders()});
	
	
	$('#myTab a , #myTab2 a').click(function (e) {
    e.preventDefault();
    $(this).tab('show');
    });

	
	$('#search-form').on('hidden', function () {
		$("[data-target=#search-form]").html('+' );
		$('.search-info').show();

    });
	$('#search-form').on('show', function () {
    $("[data-target=#search-form]").html('-' );
	$('.search-info').hide();
    })


}());


