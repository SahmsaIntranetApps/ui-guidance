/* Author:Donnie Wilcox

*/


;(function(){
	$('#screens-nav a').popover();
	}());




